import React, { useEffect, useState } from 'react'

const App = () => {


    // state defined
    const [data, setData] = useState([]);

    useEffect(() => {
        fetch('https://s3.amazonaws.com/roxiler.com/product_transaction.json')
            // fetch(' API')
            .then((result) => result.json()
                .then((res) => {
                    console.log(res);
                    setData(res);
                }))
    }, [])

    console.log(data);

    return (
        <div>
            {/* API Calling */}


            {/* fetch - To Call API*/}

            {/* then  */}


            <h1>API Calling in a Functional Component</h1>


            <table className='table table-bordered hover table-striped table-responsive-sm w-100'>

                <thead>
                    <tr>

                        <th>ID</th>
                        <th>P_Title</th>
                        <th>P_Price</th>
                        <th>P_Description</th>
                        <th>P_Category</th>
                        <th>P_Image</th>
                        <th>P_Sold</th>
                        <th>P_DateOfSale</th>

                    </tr>
                </thead>

                <tbody>

                    {

                        data.map((val,index) => {
                            return (

                                <tr key={val.id || index}>
                                    <td>{val.title}</td>
                                    <td>{val.price}</td>
                                    <td>{val.description}</td>
                                    <td>{val.category}</td>
                                    <td><img src={val.image}></img></td>
                                    <td>{val.sold}</td>
                                    <td>{val.dateOfSale}</td>
                                </tr>

                            )

                        })


                    }

                </tbody>


            </table>









        </div>
    )
}

export default App
