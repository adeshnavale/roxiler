// src/BarChartStats.js
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const BarChartStats = ({ data, selectedMonth }) => {
  // Data should be processed according to the required format
  const processedData = [
    { name: '0-100', value: 10 },
    { name: '101-200', value: 20 },
    { name: '201-300', value: 15 },
    { name: '301-400', value: 30 },
    { name: '401-500', value: 60 },
    { name: '501-600', value: 25 },
    { name: '601-700', value: 40 },
    { name: '701-800', value: 80 },
    { name: '801-900', value: 20 },
    { name: '901 above', value: 35 }
  ];

  return (
    <div className="bar-chart-container">
      <h3>Bar Chart Stats - {selectedMonth}</h3>
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={processedData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="value" fill="#00C49F" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default BarChartStats;
